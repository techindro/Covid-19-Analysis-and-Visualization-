# Data Folder

Place your three CSV files here before running the notebook or script:

- `covid.csv`
- `covid_grouped.csv`
- `coviddeath.csv`

> These files are excluded from version control via `.gitignore`.
> Download them from Kaggle or the original GeeksForGeeks project link.
