# ============================================================
# COVID-19 Analysis and Visualization using Plotly Express
# ============================================================

# ── Imports ──────────────────────────────────────────────────
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objs as go
import plotly.io as pio
import plotly.offline as py
from plotly.figure_factory import create_table

py.init_notebook_mode(connected=True)
pio.renderers.default = "browser"   # change to 'colab' if using Google Colab


# ── 1. Load Datasets ─────────────────────────────────────────
def load_data(path1="data/covid.csv",
              path2="data/covid_grouped.csv",
              path3="data/coviddeath.csv"):
    """Load all three CSV datasets and return as DataFrames."""
    df1 = pd.read_csv(path1)
    df2 = pd.read_csv(path2)
    df3 = pd.read_csv(path3)
    return df1, df2, df3


# ── 2. Clean Data ─────────────────────────────────────────────
def clean_covid(df: pd.DataFrame) -> pd.DataFrame:
    """Drop columns that are mostly NaN."""
    drop_cols = [c for c in ["NewCases", "NewDeaths", "NewRecovered"] if c in df.columns]
    df.drop(drop_cols, axis=1, inplace=True)
    return df


# ── 3. Summary Table ──────────────────────────────────────────
def show_table(df: pd.DataFrame, n: int = 15):
    colorscale = [[0, "#4d004c"], [0.5, "#f2e5ff"], [1, "#ffffff"]]
    table = create_table(df.head(n), colorscale=colorscale)
    py.iplot(table)


# ── 4. Bar Charts ─────────────────────────────────────────────
def bar_total_cases(df: pd.DataFrame, n: int = 15):
    fig = px.bar(df.head(n), x="Country/Region", y="TotalCases",
                 color="TotalCases", height=500,
                 hover_data=["Country/Region", "Continent"],
                 title=f"Top {n} Countries – Total Cases")
    fig.show()


def bar_deaths(df: pd.DataFrame, n: int = 15):
    fig = px.bar(df.head(n), x="Country/Region", y="TotalCases",
                 color="TotalDeaths", height=500,
                 hover_data=["Country/Region", "Continent"],
                 title=f"Top {n} Countries – Cases coloured by Deaths")
    fig.show()


def bar_tests_horizontal(df: pd.DataFrame, n: int = 15):
    fig = px.bar(df.head(n), x="TotalTests", y="Country/Region",
                 color="TotalTests", orientation="h", height=500,
                 hover_data=["Country/Region", "Continent"],
                 title=f"Top {n} Countries – Total Tests (horizontal)")
    fig.show()


# ── 5. Bubble / Scatter Charts ────────────────────────────────
def bubble_continent(df: pd.DataFrame):
    fig = px.scatter(df, x="Continent", y="TotalCases",
                     hover_data=["Country/Region", "Continent"],
                     color="TotalCases", size="TotalCases", size_max=80,
                     title="Continent-wise Total Cases")
    fig.show()


def bubble_country(df: pd.DataFrame, n: int = 30):
    fig = px.scatter(df.head(n), x="Country/Region", y="TotalCases",
                     hover_data=["Country/Region", "Continent"],
                     color="Country/Region", size="TotalCases", size_max=80,
                     log_y=True,
                     title=f"Top {n} Countries – Total Cases (log scale)")
    fig.show()


def bubble_cases_vs_deaths(df: pd.DataFrame, n: int = 30):
    fig = px.scatter(df.head(n), x="TotalCases", y="TotalDeaths",
                     hover_data=["Country/Region", "Continent"],
                     color="TotalDeaths", size="TotalDeaths", size_max=80,
                     log_x=True, log_y=True,
                     title="Total Cases vs Total Deaths (log-log)")
    fig.show()


# ── 6. Time-series Bar Charts (dataset2) ─────────────────────
def bar_confirmed_over_time(df2: pd.DataFrame):
    fig = px.bar(df2, x="Date", y="Confirmed", color="Confirmed",
                 hover_data=["Confirmed", "Date", "Country/Region"],
                 log_y=True, height=400,
                 title="Global Confirmed Cases Over Time")
    fig.show()


def bar_deaths_over_time(df2: pd.DataFrame):
    fig = px.bar(df2, x="Date", y="Deaths", color="Deaths",
                 hover_data=["Confirmed", "Date", "Country/Region"],
                 height=400, title="Global Deaths Over Time")
    fig.show()


# ── 7. Country-Specific Analysis ─────────────────────────────
def analyze_country(df2: pd.DataFrame, country: str = "US"):
    df_c = df2.loc[df2["Country/Region"] == country]

    for col in ["Confirmed", "Recovered", "Deaths", "New cases"]:
        fig = px.line(df_c, x="Date", y=col, height=400,
                      title=f"{country} – {col} over Time")
        fig.show()

    fig = px.scatter(df_c, x="Confirmed", y="Deaths", height=400,
                     title=f"{country} – Confirmed vs Deaths")
    fig.show()


# ── 8. Choropleth Maps ────────────────────────────────────────
def choropleth_confirmed(df2: pd.DataFrame):
    fig = px.choropleth(df2, locations="iso_alpha", color="Confirmed",
                        hover_name="Country/Region",
                        color_continuous_scale="Blues",
                        animation_frame="Date",
                        title="Global Confirmed Cases (animated)")
    fig.show()


def choropleth_deaths(df2: pd.DataFrame):
    fig = px.choropleth(df2, locations="iso_alpha", color="Deaths",
                        hover_name="Country/Region",
                        color_continuous_scale="Viridis",
                        animation_frame="Date",
                        title="Global Deaths (animated)")
    fig.show()


def choropleth_recovered(df2: pd.DataFrame):
    fig = px.choropleth(df2, locations="iso_alpha", color="Recovered",
                        hover_name="Country/Region",
                        color_continuous_scale="RdYlGn",
                        projection="natural earth",
                        animation_frame="Date",
                        title="Global Recoveries (animated)")
    fig.show()


# ── 9. Word Cloud ─────────────────────────────────────────────
def wordcloud_conditions(df3: pd.DataFrame):
    try:
        from wordcloud import WordCloud
    except ImportError:
        print("Install wordcloud: pip install wordcloud")
        return

    sentences = df3["Condition"].tolist()
    text = " ".join(sentences)
    plt.figure(figsize=(20, 20))
    plt.imshow(WordCloud(background_color="white").generate(text))
    plt.axis("off")
    plt.title("Leading Conditions in COVID-19 Deaths", fontsize=20)
    plt.tight_layout()
    plt.savefig("condition_wordcloud.png", dpi=150)
    plt.show()

    groups = df3["Condition Group"].tolist()
    text2 = " ".join(groups)
    plt.figure(figsize=(20, 20))
    plt.imshow(WordCloud(background_color="white").generate(text2))
    plt.axis("off")
    plt.title("Condition Groups in COVID-19 Deaths", fontsize=20)
    plt.tight_layout()
    plt.savefig("conditiongroup_wordcloud.png", dpi=150)
    plt.show()


# ── Main ──────────────────────────────────────────────────────
if __name__ == "__main__":
    df1, df2, df3 = load_data()
    df1 = clean_covid(df1)

    print("Dataset 1 shape:", df1.shape)
    print("Dataset 2 shape:", df2.shape)
    print("Dataset 3 shape:", df3.shape)

    # Bar charts
    bar_total_cases(df1)
    bar_deaths(df1)
    bar_tests_horizontal(df1)

    # Bubble charts
    bubble_continent(df1)
    bubble_country(df1)
    bubble_cases_vs_deaths(df1)

    # Time-series
    bar_confirmed_over_time(df2)
    bar_deaths_over_time(df2)

    # Country-specific
    analyze_country(df2, country="US")

    # Maps
    choropleth_confirmed(df2)
    choropleth_deaths(df2)
    choropleth_recovered(df2)

    # Word cloud
    wordcloud_conditions(df3)
